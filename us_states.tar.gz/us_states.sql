-- MySQL dump 10.13  Distrib 5.1.73, for apple-darwin10.3.0 (i386)
--
-- Host: localhost    Database: us_states
-- ------------------------------------------------------
-- Server version	5.1.73

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `states`
--

DROP TABLE IF EXISTS `states`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `states` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(20) NOT NULL,
  `population` int(11) NOT NULL,
  `majority` enum('D','R') NOT NULL,
  `best_export` char(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=51 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `states`
--

LOCK TABLES `states` WRITE;
/*!40000 ALTER TABLE `states` DISABLE KEYS */;
INSERT INTO `states` VALUES (1,'alabama',10000,'D','shoes'),(2,'alaska',2047,'D','oil'),(3,'arizona',108393,'R','tortillas'),(4,'arkansas',10,'R','puppies'),(5,'california',98735868,'D','pizza'),(6,'colorado',934564,'R','paper'),(7,'connecticut',194976,'R','oil'),(8,'delaware',134865,'D','textiles'),(9,'florida',7295003,'R','chips'),(10,'georgia',9085734,'D','gas'),(11,'hawaii',4867489,'R','poop'),(12,'massachusetts',385456,'D','wheels'),(13,'new mexico',12435,'D','treesap'),(14,'south dakota',1853,'D','cat toys'),(15,'idaho',456574,'R','dog food'),(16,'michigan',234536,'R','fries'),(17,'new york',3253644,'R','tires'),(18,'tennessee',73235,'D','cardboard'),(19,'illinois',975947,'R','peeps'),(20,'minnesota',548389,'D','mice'),(21,'north carolina',39057,'R','deer meat'),(22,'texas',344433,'R','phones'),(23,'indiana',35785,'D','tablets'),(24,'mississippi',678963,'R','file paper'),(25,'north dakota',9235,'D','fiber'),(26,'utah',82734,'D','software'),(27,'iowa',96728,'D','windows'),(28,'missouri',8359,'R','hemp'),(29,'ohio',90834,'D','weed'),(30,'vermont',947594,'D','beer'),(31,'kansas',497985,'R','also beer'),(32,'montana',2487,'D','beer too'),(33,'oklahoma',246379,'R','salmon'),(34,'virginia',97294749,'D','piles'),(35,'kentucky',238678,'R','condoms'),(36,'nebraska',348648,'D','snakeskin'),(37,'oregon',29738,'D','hardware'),(38,'washington',349879,'D','tools'),(39,'louisiana',39486479,'R','cups'),(40,'nevada',343874,'D','tables'),(41,'pennsylvania',48673,'D','rubie'),(42,'west virginia',376499,'R','railses'),(43,'maine',398749,'R','poopie'),(44,'new hampshire',398579,'D','pies'),(45,'rhode island',35987,'R','plates'),(46,'wisconsin',59879,'D','fenches'),(47,'maryland',59869,'D','potatoes'),(48,'new jersey',6872,'D','screens'),(49,'south carolina',48569,'R','hemp'),(50,'wyoming',2,'D','peanuts');
/*!40000 ALTER TABLE `states` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-02-03 15:36:58
